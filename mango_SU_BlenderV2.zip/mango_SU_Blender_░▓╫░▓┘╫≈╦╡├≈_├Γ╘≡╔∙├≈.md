# mango SU to Blender Live Link 安装、操作说明与免责声明

适用插件：

- SketchUp 插件：`packages/su_to_blender_live_link.rbz`
- Blender 插件：`packages/su_to_blender_blender_addon.zip`

说明图：

![mango SU to Blender Live Link workflow](./mango_su_blender_workflow.svg)

## 一、插件用途

`mango SU to Blender Live Link` 用于在 SketchUp 与 Blender 之间进行本地实时联动。

目前支持：

- SketchUp 模型同步到 Blender
- Blender 选中模型发送到 SketchUp
- 材质颜色同步
- 图片贴图同步
- UV 坐标同步
- SketchUp 摄像机同步到 Blender
- 文件桥同步，避免大模型通过端口传输时卡顿
- Blender 来源模型不会再被 SketchUp 回传到 Blender，避免双向同步回声
- 一键切换中文界面

## 二、安装说明

### 1. 安装 SketchUp 插件

1. 打开 SketchUp。
2. 进入 `扩展程序管理器` 或 `Extension Manager`。
3. 点击 `安装扩展程序`。
4. 选择文件：
   `packages/su_to_blender_live_link.rbz`
5. 安装完成后，重启 SketchUp。
6. 在 SketchUp 菜单中找到：
   `mango SU Live Link`

### 2. 安装 Blender 插件

1. 打开 Blender。
2. 进入 `Edit > Preferences > Add-ons`。
3. 点击 `Install...`。
4. 选择文件：
   `packages/su_to_blender_blender_addon.zip`
5. 勾选启用：
   `mango SU to Blender Live Link`
6. 在 3D View 右侧栏找到：
   `mango Link > mango SU Live Link`

## 三、基础操作流程

### 1. SketchUp 同步到 Blender

1. 先打开 Blender。
2. 在 Blender 右侧 `mango Link` 面板中点击 `Start Receiver`。
3. 打开 SketchUp。
4. 在 SketchUp 菜单 `mango SU Live Link` 中点击 `Start Live Sync`。
5. SketchUp 模型会写入本地文件桥。
6. Blender 会自动读取并生成模型。

常用命令：

- `Start Live Sync`：开始实时同步
- `Sync Once`：同步一次
- `Sync Selection Once`：只同步当前选中对象
- `Force Resend Snapshot`：强制重发完整快照
- `Sync Camera Only`：只同步 SketchUp 摄像机
- `Show Status`：查看当前状态

### 2. Blender 同步到 SketchUp

1. SketchUp 中先点击 `Start Live Sync`。
2. Blender 中选择要发送的模型。
3. 在 Blender 的 `mango SU Live Link` 面板中点击：
   `Send Selected to SketchUp`
4. SketchUp 会在下一次同步 tick 自动导入该模型。
5. 如果需要立即手动导入，可在 SketchUp 菜单点击：
   `Import Blender Snapshot Once`

说明：

- 同一个 Blender 对象重复发送到 SketchUp 时，会替换上一次导入的同 ID 对象，不会重复堆叠。
- 从 Blender 导入 SketchUp 的对象带有插件标记，不会再被 SketchUp 回传到 Blender。

### 3. 切换中文界面

SketchUp：

- 菜单中点击：
  `切换中文界面 / Toggle Chinese UI`

Blender：

- 面板顶部点击：
  `Switch to Chinese` 或 `切换到 English`

## 四、文件桥路径

插件默认使用本地文件夹：

`C:/tmp/su_to_blender_live_link`

常见文件：

- `latest_snapshot.txt`：SketchUp 到 Blender 的最新快照索引
- `blender_to_su_latest.txt`：Blender 到 SketchUp 的最新快照索引
- `snapshot_*.json`：SketchUp 生成的模型快照
- `blender_to_su_*.json`：Blender 生成的模型快照
- `textures/`：SketchUp 导出的贴图缓存

一般不需要手动修改这些文件。

## 五、使用建议

- 大场景优先使用 `Sync Selection Once`。
- 材质贴图建议使用本地图片路径，不建议只使用程序纹理。
- Blender 复杂节点材质无法 100% 转换为 SketchUp 材质，插件会优先同步基础颜色、图片贴图和 UV。
- SketchUp 与 Blender 都建议使用同一台电脑本地运行。
- 如果同步异常，先查看两边面板或菜单中的 `Show Status`。

## 六、常见问题

### 1. Blender 没有收到 SketchUp 模型

检查：

- Blender 是否已点击 `Start Receiver`
- Blender 面板是否显示 `UI processor: running`
- SketchUp 是否已点击 `Start Live Sync`
- `C:/tmp/su_to_blender_live_link/latest_snapshot.txt` 是否存在

### 2. SketchUp 没有收到 Blender 模型

检查：

- SketchUp 是否已点击 `Start Live Sync`
- Blender 是否选中了 Mesh 对象
- Blender 面板是否显示 `Wrote ... object(s) for SketchUp`
- `C:/tmp/su_to_blender_live_link/blender_to_su_latest.txt` 是否存在

### 3. 贴图方向或 UV 不完全一致

插件会同步基础 UV，但以下情况可能仍有差异：

- Blender 材质使用复杂 Mapping 节点
- 使用程序纹理而不是图片纹理
- 多重 UV、UDIM、投射坐标、对象坐标、生成坐标
- 非常复杂的节点混合材质

建议使用 Image Texture + UV Map 的常规材质结构。

### 4. 同步速度慢

建议：

- 使用 `Sync Selection Once`
- 隐藏不需要同步的对象
- 减少高面数模型
- 检查贴图是否过大
- 避免频繁同步复杂大场景

## 七、免责声明

本插件为本地辅助联动工具，按现状提供。

使用者应理解并接受以下事项：

- 插件不保证在所有 SketchUp、Blender、操作系统版本中完全兼容。
- 插件不保证复杂材质、复杂 UV、程序纹理、节点材质、动画、骨骼、约束、插件生成对象等内容能完整转换。
- 插件同步过程中可能创建、覆盖或删除由插件标记的联动对象。
- 使用前请自行备份重要 SketchUp、Blender 项目文件。
- 作者不对因使用插件造成的数据丢失、模型错误、材质错误、项目损坏、生产延误或其他直接与间接损失承担责任。
- 插件仅建议用于测试、辅助建模、流程预览和非关键生产环节。

作者：mango

